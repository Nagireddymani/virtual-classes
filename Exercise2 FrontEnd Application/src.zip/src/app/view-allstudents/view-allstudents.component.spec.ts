import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAllstudentsComponent } from './view-allstudents.component';

describe('ViewAllstudentsComponent', () => {
  let component: ViewAllstudentsComponent;
  let fixture: ComponentFixture<ViewAllstudentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAllstudentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAllstudentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
