import { Component, OnInit } from '@angular/core';
import { Student } from '../Student';
import { StudentApiService } from '../student-api.service';

@Component({
  selector: 'app-view-allstudents',
  templateUrl: './view-allstudents.component.html',
  styleUrls: ['./view-allstudents.component.css']
})
export class ViewAllstudentsComponent implements OnInit {
  
  studentList:Student[];
  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
    this.service.viewAllStudent().subscribe(
      (success)=>{
        this.studentList=success;
      },
     (error)=>{
         alert("No Students in the Record");
     }
      );
  }

}
