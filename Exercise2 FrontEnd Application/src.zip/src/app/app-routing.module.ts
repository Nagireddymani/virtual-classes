import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddStudentComponent } from './add-student/add-student.component';
import { SearchStudentComponent } from './search-student/search-student.component';
import { DeleteStudentComponent } from './delete-student/delete-student.component';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { ViewAllstudentsComponent } from './view-allstudents/view-allstudents.component';
import { SearchStudentBynameComponent } from './search-student-byname/search-student-byname.component';


const routes: Routes = [
  {
    path: "add-student",   component: AddStudentComponent
  },
  {
    path: "search-student", component :SearchStudentComponent
  },
  {
    path: "delete-student", component:DeleteStudentComponent
  },
  {
    path: "update-student", component:UpdateStudentComponent
  },
  {
    path: "view-allstudents" , component: ViewAllstudentsComponent
  },
  {
    path: "search-student-byname", component : SearchStudentBynameComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
