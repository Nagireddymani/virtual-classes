import { Component, OnInit } from '@angular/core';
import { StudentApiService } from '../student-api.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
  }

  onClickSubmit(student)
  {
     this.service.addStudent(student).subscribe(
       (success)=>{
         alert("Student With Id : "+student.studentId+" is added");
       },
       (error)=>{
        alert("Student With Id : "+student.studentId+" is Already Exist");
       }


     )
  }
}
