import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { SearchStudentComponent } from './search-student/search-student.component';
import { DeleteStudentComponent } from './delete-student/delete-student.component';
import { UpdateStudentComponent } from './update-student/update-student.component';
import { ViewAllstudentsComponent } from './view-allstudents/view-allstudents.component';
import { SearchStudentBynameComponent } from './search-student-byname/search-student-byname.component';

@NgModule({
  declarations: [
    AppComponent,
    AddStudentComponent,
    SearchStudentComponent,
    DeleteStudentComponent,
    UpdateStudentComponent,
    ViewAllstudentsComponent,
    SearchStudentBynameComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
