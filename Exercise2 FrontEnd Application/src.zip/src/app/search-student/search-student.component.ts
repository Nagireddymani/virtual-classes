import { Component, OnInit } from '@angular/core';
import { StudentApiService } from '../student-api.service';
import { Student } from '../Student';

@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
 public student:Student;
  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
  }
 onClickSubmit(data)
 {
    this.service.searchUserById(data.studentId).subscribe(
    (student)=>{
      this.student=student;
      console.log(this.student);
      
    }
    )
 }
}
