import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Student } from './Student';

@Injectable({
  providedIn: 'root'
})
export class StudentApiService {
  
  baseUrl:string="http://localhost:9001/student/";
  constructor(private http:HttpClient) {
  }
   
  public searchUserById(studentId:number):Observable<any>
  {
      return this.http.get(this.baseUrl+"id/"+studentId);
  }
  public searchUserByName(studentName:string):Observable<any>
  {
      return this.http.get(this.baseUrl+"name/"+studentName);
  }
 
  public deleteUserById(studentId:number):Observable<any>
  {
      return this.http.delete(this.baseUrl+"delete/id/"+studentId);
  }

  public addStudent(student:Student):Observable<any>
  {
      return this.http.post(this.baseUrl+"add/",student);
  }
  public updateStudent(student:Student):Observable<any>
  {
      return this.http.put(this.baseUrl+"update/",student);
  }
  public viewAllStudent():Observable<Array<any>>
  {
      return this.http.get<Array<any>>(this.baseUrl+"all");
  }
}
