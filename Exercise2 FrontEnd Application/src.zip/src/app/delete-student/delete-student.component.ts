import { Component, OnInit } from '@angular/core';
import { StudentApiService } from '../student-api.service';

@Component({
  selector: 'app-delete-student',
  templateUrl: './delete-student.component.html',
  styleUrls: ['./delete-student.component.css']
})
export class DeleteStudentComponent implements OnInit {

  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
  }
  onClickSubmit(data)
  {
    if(confirm("Are you sure?"))
    {
           this.service.deleteUserById(data.studentId).subscribe(
             (success)=>{
               alert("Student with Id :"+data.studentId+"is Deleted");
             },
             (error)=>{
                alert("Student Not Deleted");
             }
           )
    }
  }

}
