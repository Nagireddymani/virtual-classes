import { Component, OnInit } from '@angular/core';
import { StudentApiService } from '../student-api.service';
import { Student } from '../Student';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
   status:boolean=false;
   student:Student;
   studentId:number;
   studentName:string;
   dob:Date;
  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
  }
  onClickSubmit(data)
  {
     
     this.service.searchUserById(data.studentId).subscribe(
       (success)=>{
         this.status=true;
         this.student=success;
         this.studentId=this.student.studentId;
         this.studentName=this.student.studentName;
         this.dob=this.student.dob;
         console.log(this.student);
       },
       (error)=>{
        alert("Student with id : "+data.studentId+" is Not Found");
      }
     )
  }

  updateStudent(student)
  {
     this.service.updateStudent(student).subscribe(
       (success)=>{
          alert("Student with Id : "+ student.studentId+" is Updated");
       },
       (error)=>{
         alert("Student cannot be Modified");
       }


     )
  }
}
