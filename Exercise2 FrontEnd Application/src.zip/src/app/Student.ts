export class Student
{
    public studentId:number;
    public studentName:string;
    public dob:Date;
}