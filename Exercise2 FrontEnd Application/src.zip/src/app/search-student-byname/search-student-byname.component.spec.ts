import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchStudentBynameComponent } from './search-student-byname.component';

describe('SearchStudentBynameComponent', () => {
  let component: SearchStudentBynameComponent;
  let fixture: ComponentFixture<SearchStudentBynameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchStudentBynameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchStudentBynameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
