import { Component, OnInit } from '@angular/core';
import { Student } from '../Student';
import { StudentApiService } from '../student-api.service';

@Component({
  selector: 'app-search-student-byname',
  templateUrl: './search-student-byname.component.html',
  styleUrls: ['./search-student-byname.component.css']
})
export class SearchStudentBynameComponent implements OnInit {

  student:Student;
  constructor(private service:StudentApiService) { }

  ngOnInit(): void {
  }
  onClickSubmit(data)
  { 
         this.service.searchUserByName(data.studentName).subscribe(
           (success)=>{
              this.student=success;
              if(this.student==null)
                  alert("Student with Name : " +data.studentName+" is Not Found") 
           }
         )
  }
}
