export class Contacts
{
    constructor(public contactId:number,public firstName:string,public lastName:string,public mobileNumber:number,public mailId:string
        ,public dateOfBirth:string,public doorNo:number,public appartmentName:string,public street:string,public city:string
        ,public country:string,public pincode:number)
    {

    }
}